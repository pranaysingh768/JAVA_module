class AddByte{

	public static void main(String[] args){

	byte no1 = 100;
	byte no2 = (byte)200;
	byte sum = (byte) (no1 + no2);
	System.out.println("no2 is = "+no2);
	System.out.println("Sum is = "+sum);
}
	
}


