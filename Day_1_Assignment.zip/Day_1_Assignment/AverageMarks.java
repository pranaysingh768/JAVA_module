import java.util.*;
class AverageMarks{

	public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
	int mark;
	int sum=0;
	for(int i=1;i<=5;i++){

		System.out.print("Enter "+i+"st mark:: ");
		mark = sc.nextInt();
		sum += mark;			
		}
	System.out.println("Sum of 5 subjects:: "+sum);
	double avg = sum * 100 / 500;
	System.out.println("Average of 5 subjects:: "+avg+"%");
	
	
	}
	
}


