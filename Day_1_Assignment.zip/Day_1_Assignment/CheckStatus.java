import java.util.*;
class CheckStatus{

	public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter Gender:: ");
	char gender = sc.next().charAt(0);
	System.out.print("Enter Age:: ");
	int age = sc.nextInt();

	if(gender == 'M' || gender == 'm' && age >= 21){

		System.out.println("Male persone is eligible for married");
	}

	else if(gender == 'F' || gender == 'f' && age >= 21){

		System.out.println("Female persone is eligible for married");
	}
	else{

		System.out.println("persone is not eligible for married");
	}

	

	

	
	}
	
}


