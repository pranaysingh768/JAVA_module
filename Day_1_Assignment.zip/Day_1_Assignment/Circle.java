import java.util.*;
class Circle{

	public static void main(String[] args){

	Scanner sc  = new Scanner(System.in);
	System.out.print("Enter Radius:: ");
	double radius = sc.nextDouble ();
	double area = 3.14 * radius * radius;
	double circumfarence = 3.14 * 2 * radius;  
		
	System.out.println("Area Of circle "+area);
	System.out.println("Circumfarence of Circle "+circumfarence);

	}
	
}


