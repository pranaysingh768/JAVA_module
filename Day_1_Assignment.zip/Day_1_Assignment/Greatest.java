import java.util.*;
class Greatest{

	public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter 1st no:: ");
	int no1 = sc.nextInt();

	System.out.print("Enter 2nd no:: ");
	int no2 = sc.nextInt();

	System.out.print("Enter 3rd no:: ");
	int no3 = sc.nextInt();
	
	if(no1 > no2 && no1 > no3){

		System.out.println("no1 is big");
	}
	else if(no2 > no1 && no2 > no3){

		System.out.println("no2 is big");
	}
	else{

		System.out.println("no3 is big");
	}

	

	
	}
	
}


