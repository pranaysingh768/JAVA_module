import java.util.*;
class GrossSal{

	public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter Basic Salary:: ");
	int salary = sc.nextInt();
	double HRA;
	double DA;

	if(salary < 1000){

		HRA = 10 * salary / 100;
		DA = 90 * salary / 100;
		
	}
	else{

		HRA = 2000;
		DA = 98 * salary / 100;
	}

	double gross = salary + HRA + DA;

	System.out.print("Gross Salary:: "+gross);

	
	}
	
}


