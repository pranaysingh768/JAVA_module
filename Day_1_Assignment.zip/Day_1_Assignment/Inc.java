import java.util.*;
class Inc{

	public static void main(String[] args){

	int x = 5;

	System.out.println(x++ + ++x);

	

	

	
	}
	
}


