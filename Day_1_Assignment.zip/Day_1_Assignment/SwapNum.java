import java.util.*;
class SwapNum{

	public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter 1st no:: ");
	int no1 = sc.nextInt();

	System.out.print("Enter 2ns no:: ");
	int no2 = sc.nextInt();

	System.out.print("Before swap:: "+no1+" and "+no2+"\n");

	no1 = no1 - no2;
	no2 = no2 + no1;
	no1 = no2 - no1; 

	System.out.print("After swap:: "+no1+" and "+no2);

	
	}
	
}


