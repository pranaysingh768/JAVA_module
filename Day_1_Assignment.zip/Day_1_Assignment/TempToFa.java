import java.util.*;
class TempToFa{

	public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter Temperature in Fahrenheit:: ");
	int F = sc.nextInt();
	double C = 5*(F-32)/9; 
	
	System.out.println("Temperature in Celcius:: "+C);
	
	
	}
	
}


