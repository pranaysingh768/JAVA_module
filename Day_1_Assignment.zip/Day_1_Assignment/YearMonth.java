import java.util.*;
class YearMonth{

	public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter Days:: ");
	int days = sc.nextInt();
	double month = days / 30;
	double year = month / 12;
	
	System.out.println("Years:: "+year);
	System.out.println("Months:: "+month);
	System.out.println("Days:: "+days);
	
	
	}
	
}


