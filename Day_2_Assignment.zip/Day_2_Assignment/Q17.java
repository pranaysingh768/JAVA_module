import java.util.*;

public class Q17 {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number:: ");

        int num = sc.nextInt();
        int rem=0;
        int mod;

        while(num > 0){

            mod = num % 10;
            rem = (rem * 10) + mod;
            num = num / 10;

        }

        System.out.println("reverse no:: "+rem);
    }
}
