import java.util.*;

public class Q18 {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter no:: ");

        int num = sc.nextInt();
        int count = 0;
        for(int i=2;i<=num;i++){

            if(num % i == 0){

                count++;
            }
        }

        if(count == 1){
            System.out.println("prime");
        }
        else{
            System.out.println("not prime");
        }
    }
}
