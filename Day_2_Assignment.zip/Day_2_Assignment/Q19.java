import java.util.*;

public class Q19 {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter no:: ");

        int num = sc.nextInt();
        int sqr;
        int sum = 0;
        for(int i=1;i<=num;i++){

            sqr = i * i;
            sum += sqr;
        }

        System.out.println("Sum is:: "+sum);

        
    }
}
