import java.util.*;

public class Q20 {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter no1:: ");
        int num1 = sc.nextInt();
        System.out.print("Enter no2:: ");
        int num2 = sc.nextInt();
        int count;
        for(int i=num1;i<=num2;i++){

            count= 0;
            for(int j=2;j<=i;j++){

                if(i % j == 0){

                    count++;
                }
            }

            if(count == 1){
                System.out.println(i);
            }
            
            
        }

       
    }
}
