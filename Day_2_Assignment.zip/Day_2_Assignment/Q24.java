import java.util.*;

public class Q24 {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        int[] arr = new int[5];

        System.out.print("Enter Searching ele:: ");

        int search = sc.nextInt();

        for(int i=0;i<arr.length;i++){

            System.out.print("Enter element "+i+" :: ");
            arr[i] = sc.nextInt();
        }

        int flag =0;
        for(int a : arr){
        
            if(search == a){

                flag = 1;
                System.out.println(search+" is found");
            }
        }

        if(flag == 0){

            System.out.println(search+" is not found");
        }
    }
}
