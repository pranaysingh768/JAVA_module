import java.util.*;

public class Q25 {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        int[] arr = new int[5];
        int oddSum = 0;
        int evenSum = 0;
        for(int i=0;i<arr.length;i++){

            System.out.print("Enter element "+i+" :: ");
            arr[i] = sc.nextInt();
        }

        
        for(int a : arr){
        
           if(a % 2 == 0){

            evenSum += a;
           }
           else{

            oddSum += a;
           }
        }

       
            System.out.println("Odd Sum:: "+oddSum);
            System.out.println("Even Sum:: "+evenSum);
        
    }
}
