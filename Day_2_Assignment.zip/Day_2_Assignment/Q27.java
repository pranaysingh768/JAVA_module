import java.util.*;

public class Q27 {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        int[] arr = new int[5];
        
        for(int i=0;i<arr.length;i++){

            System.out.print("Enter element "+i+" :: ");
            arr[i] = sc.nextInt();
        }

        int small = arr[0];
        int big = arr[0];

        
        for(int a : arr){
        
           if(a < small){

            small = a;
           }
           if(a > big){

            big = a;
           }
        }

       
            System.out.println("Smallest:: "+small);
            System.out.println("greatest:: "+big);
        
    }
}
