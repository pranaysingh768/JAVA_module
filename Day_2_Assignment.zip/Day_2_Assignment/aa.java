import java.util.*;

public class aa {
    
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

       
        System.out.print("Enter no:: ");

        int num=sc.nextInt();
String s="pranay";

int num1=123;

String[] arrOfStr = s.split(""); 

        

       
    }
}
